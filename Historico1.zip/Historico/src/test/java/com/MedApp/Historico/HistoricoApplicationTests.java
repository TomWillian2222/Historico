package com.MedApp.Historico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoricoApplicationTests {

	@Test
	void contextLoads() {
	}

}
